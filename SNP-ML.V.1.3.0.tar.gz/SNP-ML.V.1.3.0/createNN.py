import sys
total = len(sys.argv)
cmdargs = str(sys.argv)
outputfile = sys.argv[1]

import numpy as np
x_train = np.genfromtxt("x_03071979.csv", delimiter=',',dtype='float32')
y_train = np.genfromtxt("y_03071979.csv", delimiter=',',dtype='float32')
import numpy as np

import numpy as np
import pyrenn as prn
net = prn.CreateNN([x_train.shape[1],4,1])
net = prn.train_LM(np.transpose(x_train),y_train,net,verbose=True,k_max=1000,E_stop=1e-5)
prn.saveNN(net,str(outputfile)+".nn")