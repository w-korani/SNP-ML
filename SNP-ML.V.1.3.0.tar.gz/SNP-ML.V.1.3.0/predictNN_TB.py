import sys
total = len(sys.argv)
cmdargs = str(sys.argv)
inputfile = sys.argv[1]

import numpy as np
x_test = np.genfromtxt("x_03071979b.csv", delimiter=',',dtype='double')

import pyrenn as prn
net = prn.loadNN(str(inputfile)+".nn")
ytest_LM = prn.NNOut(np.transpose(x_test),net);
import pandas as pd
df = pd.DataFrame(ytest_LM)
df.to_csv('nn_03071979b_out.csv')

import math
from numpy import nan
from numpy import inf
x_test[x_test == nan] = 0
x_test[x_test == inf] = 0 
#x_test[x_test == -inf] = 0

import cPickle as pickle
file = open(str(inputfile)+".tb",'rb')
bagging = pickle.load(file)
file.close()
from sklearn.ensemble import BaggingClassifier
y_tb = bagging.predict(x_test)
import pandas as pd
df = pd.DataFrame(y_tb)
df.to_csv('tb_03071979b_out.csv')