import sys
total = len(sys.argv)
cmdargs = str(sys.argv)
inputfile = sys.argv[1]

import numpy as np
x_test = np.genfromtxt("x_03071979b.csv", delimiter=',',dtype='double')

import pyrenn as prn
net = prn.loadNN(str(inputfile)+".nn")
ytest_LM = prn.NNOut(np.transpose(x_test),net);
import pandas as pd
df = pd.DataFrame(ytest_LM)
df.to_csv('nn_03071979b_out.csv')
